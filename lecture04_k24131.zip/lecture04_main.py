from sagyo1 import sagyo1 
from Sagyo2 import Sagyo2
from Sagyo3 import Sagyo3

sagyo1.sagyo1(self=sagyo1,duration=10)
s=Sagyo2.transcribe_audio(self=Sagyo2)
Sagyo3.__init__(self=Sagyo3,text=s)
Sagyo3.outputTextFile(self=Sagyo3)